import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../services/api.service';
import {Router} from '@angular/router';

@Component({
  selector: 'ngx-ecommerce',
  templateUrl: './e-commerce.component.html',
})
export class ECommerceComponent {
institutes:any[]=[];
institute:any[] = [];
students:any[]=[];
display:boolean = false;
studentReq:any[]=[
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
];

classes=[
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
];
fee=['week','month'];
studentPendingFee=[
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
]
date=['1st MAY 2020','10th MAY 2020','15th MAY 2020'];
study = [
{name:'Prashant Gupta',msg:'has requested to be added',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'9874561230'},
{name:'Prashant Gupta',msg:'has requested to be added',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'9874561230'},
{name:'Prashant Gupta',msg:'has requested to be added',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'9874561230'},
{name:'Prashant Gupta',msg:'has requested to be added',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'9874561230'},
]
  constructor(private api:ApiService, private router:Router) { }

  ngOnInit() {
  	this.getInstitutes();
  	// this.getStudents();

  }
getInstitutes(){
	this.api.getInstitutes().subscribe(
		data => {
			
		  this.institutes = data;

		console.log('institutes - ' + JSON.stringify(this.institutes));
		this.institute = JSON.parse(JSON.stringify(this.institutes));
		console.log(this.institute);


	  });
	this.display = true;
 }
getStudents(){
		this.api.getStudents().subscribe(data => {
			this.students = data;
		},err=>console.error(err))
	}  

onClick(){
	this.router.navigate(['/pages/institute/add-institute']);
}	
}

