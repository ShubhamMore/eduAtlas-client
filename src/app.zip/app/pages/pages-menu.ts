import { NbMenuItem } from '@nebular/theme';
import {PagesComponent} from './pages.component';


export const MENU_ITEMS: NbMenuItem[] = [
  {
    title:'Home',
    icon:'home-outline',
    link:'/pages/home',
    home:true
  },

  
 
  {
    title:'Institute',
    icon:'home-outline',

    children: [
      {
        title: 'Add Institute',
        link: '/pages/institute/add-institute',

        
      },
      {
        title: 'Manage Institute',
        link: '/pages/institute/manage-institute'
      },
     
    
    
    ]
  },
  
    {
    title: 'Dashboard',
    icon: 'layout-outline',
    link: '/pages/dashboard',
    pathMatch:'full',
    hidden:true
  },
  {
    title: 'Students',
 
    icon:'person-outline',
    hidden:true,
    children:[
      {
        title: 'Add Students',
        link: '/pages/institute/add-students'
      },
      {
        title: 'Manage Students',
        link:'/pages/institute/manage-students'
      }
    ]
  },
  {
    title: 'Branch Configuration',
   
    icon:'share-outline',
    link: '/pages/institute/branch-config',
    hidden:true,
    children:[
      {
        title:'Courses',
        children:[
          {
            title:'Add Course',
            link:'/pages/institute/branch-config/add-courses'
          },
          {
            title:'Manage Courses',
            link:'/pages/institute/branch-config/manage-course'
          }
        ]
      },
     {
       title:'Batches',
       children:[
        {
          title:'Add Batches',
          link:'/pages/institute/branch-config/add-batches'
        },
        {
          title:'Manage Batches',
          link:'/pages/institute/branch-config/manage-batch'
        }
       ]
     },
     {
       title:'Discount',
       children:[
        {
          title:'Add Discount',
          link:'/pages/institute/branch-config/discount'
        },
        {
          title:'Manage Discount',
          link:'/pages/institute/branch-config/manage-discount'
        }
       ]
     },
      {
        title: 'Receipt',
        children:[
          {
            title:'Add Receipt',
            link:'/pages/institute/branch-config/receipt-conf'
          },
          {
            title:'Manage Receipt',
            link:'/pages/institute/branch-config/manage-receipt'
          }
        ]
      },
      {
        title:'Role',
        children:[
          {
            title:'Add Role',
            link:'/pages/institute/branch-config/role-management'
          },
          {
            title:'Manage Role',
          }
        ]
      },
     
    ]
  },
 {
   title:'Schedule',
   hidden:true,
   children:[
     {
       title:'Add Schedule',
         
     }

   ]
 }
  
];
