import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-add-schedule',
  templateUrl: './add-schedule.component.html',
  styleUrls: ['./add-schedule.component.scss']
})
export class AddScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
