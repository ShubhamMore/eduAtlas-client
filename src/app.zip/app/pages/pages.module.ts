import { NgModule } from '@angular/core';
import { NbMenuModule, NbLayoutModule,NbCardModule,NbIconModule,NbListModule,NbSelectModule,NbButtonModule } from '@nebular/theme';
import { NbEvaIconsModule } from '@nebular/eva-icons';

import { ThemeModule } from '../@theme/theme.module';
import { PagesComponent } from './pages.component';

import { PagesRoutingModule } from './pages-routing.module';
import { MiscellaneousModule } from './miscellaneous/miscellaneous.module';
import {ButtonModule} from 'primeng/button';




import { AddCourseComponent } from './institute/branch-conf/add-course/add-course.component';
import { AddBatchesComponent } from './institute/branch-conf/add-batches/add-batches.component';
import { DiscountComponent } from './institute/branch-conf/discount/discount.component';
import { ReceiptConfComponent } from './institute/branch-conf/receipt-conf/receipt-conf.component';
import { RoleManagementComponent } from './institute/branch-conf/role-management/role-management.component';
import { AddScheduleComponent } from './schedule/add-schedule/add-schedule.component';
import { HomeComponent } from './home/home.component';
import {ECommerceComponent} from './e-commerce/e-commerce.component';
import { MembershipComponent } from './membership/membership.component';
//import { InstAddDialogComponent } from './institute/add-institute/inst-add-dialog/inst-add-dialog.component';



@NgModule({
  imports: [
    PagesRoutingModule,
    ThemeModule,
    NbMenuModule,
    MiscellaneousModule,
    ButtonModule,
    NbLayoutModule,
    NbCardModule,
    NbEvaIconsModule,
    NbIconModule,
    NbListModule,
    NbSelectModule,
    NbButtonModule
  ],
  declarations: [
    PagesComponent,
    AddScheduleComponent,
    HomeComponent,
    ECommerceComponent,
    MembershipComponent
    

    
 
    

    
 

    
  

    // ClassifiedComponent,
    // CreateClassifiedComponent,
    // ManageClassifiedComponent,
    // BusinessComponent,
    // CreateBusinessComponent,
    // ManageBusinessComponent,
  
  ],

})
export class PagesModule {
}
