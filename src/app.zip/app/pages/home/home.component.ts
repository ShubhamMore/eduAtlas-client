import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../services/api.service';
import {Router} from '@angular/router';
import {MENU_ITEMS} from '../pages-menu';

@Component({
  selector: 'ngx-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
institutes:any;
institute = {institutes:[]};
students:any[]=[];
display:boolean = false;
studentReq:any[]=[
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
{name:'Prashant Gupta',msg:'to be added to',institute:'IMS PITAMPURA',email:'prashant.gupta@gmail.com',contact:'0123456789'},
];

classes=[
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
{date:'05',month:'APR',topic:'Logical Reasoning',time:'4:00 Pm to 6:00 PM',batch:'BATCH', class:'MA1'},
];
fee=['week','month'];
studentPendingFee=[
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
{date:'05',month:'MAR',name:'Prashant Gupta',institute:'institute1',course:'course1',batch:'batch1',roll:'123456',fee:'25000'},
]
inst=['institute1','institute2','institute3'];
  constructor(private api:ApiService, private router:Router) { }

  ngOnInit() {

  	this.getInstitutes();
  	this.getStudents();

   		 MENU_ITEMS[2].hidden = true;
       MENU_ITEMS[3].hidden = true;
       MENU_ITEMS[4].hidden = true;

  }

  getInstitutes(){
	this.api.getInstitutes().subscribe(
		data => {
			
		  this.institutes = data;

		// console.log('institutes - ' + JSON.stringify(this.institutes));
		this.institute = JSON.parse(JSON.stringify(this.institutes));
		console.log(this.institute);
		if(this.institute.institutes.length){
			this.display = true;
			console.log(this.display);
		}
	  

	  });

 }
// getInstitutes(){
// 	this.api.getInstitutes().subscribe(data => {
// 		this.institutes = data;
// 			console.log(this.institutes);
// 			if(this.institutes[1])
// 		{
// 			this.display = true;
// 			console.log(this.display);

// 		}
// 	},err=>console.error(err))


// }
getStudents(){
		this.api.getStudents().subscribe(data => {
			this.students = data;
		},err=>console.error(err))
	}  

onClick(){
	this.router.navigate(['/pages/institute/add-institute']);
}	
viewInstitute(id:string){
	this.router.navigate(['/pages/institute/view-institute/',id]);
}
}
