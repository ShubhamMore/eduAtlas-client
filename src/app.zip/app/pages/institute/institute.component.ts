import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-institute',
  templateUrl: './institute.component.html',
  styleUrls: ['./institute.component.scss']
})
export class InstituteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
