import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstAddDialogComponent } from './inst-add-dialog.component';

describe('InstAddDialogComponent', () => {
  let component: InstAddDialogComponent;
  let fixture: ComponentFixture<InstAddDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstAddDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstAddDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
