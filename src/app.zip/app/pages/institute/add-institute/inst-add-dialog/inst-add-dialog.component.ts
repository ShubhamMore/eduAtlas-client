import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-inst-add-dialog',
  templateUrl: './inst-add-dialog.component.html',
  styleUrls: ['./inst-add-dialog.component.scss']
})
export class InstAddDialogComponent implements OnInit {
	title:string;
  constructor() { }

  ngOnInit() {
  }

}
