import { Component, OnInit } from '@angular/core';
import {instituteData} from '../../../../../assets/dataTypes/dataType';
import {ApiService} from '../../../../services/api.service';
import {ActivatedRoute,Router} from '@angular/router'
import {MENU_ITEMS} from '../../../pages-menu';
import { LocalDataSource } from 'ng2-smart-table';
import { SmartTableData } from '../../../../@core/data/smart-table';


@Component({
  selector: 'ngx-manage-institute',
  templateUrl: './manage-institute.component.html',
  styleUrls: ['./manage-institute.component.scss']
})
export class ManageInstituteComponent implements OnInit {

confirmDelete:boolean;
institutes:any;
institute = {institutes:[]};
user:instituteData;
displayData:boolean;



  constructor(private api:ApiService, private router:Router) { 

  }
 getInstitutes(){
	this.api.getInstitutes().subscribe(
		data => {
			
		  this.institutes = data;

		console.log('institutes - ' + JSON.stringify(this.institutes));
		this.institute = JSON.parse(JSON.stringify(this.institutes));
		console.log(this.institute);
	   MENU_ITEMS[2].hidden = true;
	   MENU_ITEMS[3].hidden = true;
	   MENU_ITEMS[4].hidden = true;

	  });

 }

  getInstitute(id:string){

  	// this.api.getInstitute(id).subscribe(data=>{
  	// 	this.user = data;
  	// 	this.displayData = true;
  	
  	// });
  	this.router.navigate(['/pages/institute/view-institute',id]);
  }
  ngOnInit() {
		this.getInstitutes();
  }
updateInstitute(id:string){
	// this.api.getInstitute(id).subscribe(data => {
	// 	this.user = data;
	// 	console.log(data);
	// 	this.user.iname = 'sunny';

	// this.api.updateInstitute(this.user)
	// 	.subscribe(() => {
	// 		this.getInstitutes();
	// 	});
	// });
this.router.navigate(['/pages/institute/edit-institute',id]);
} 

delete(id:string){

	this.api.deleteInstitute(id)
	.subscribe(() => console.log(`institute with id ${id} deleted`),
		(err)=>console.log(err))
	const i = this.institute.institutes.findIndex(e => e._id === id)
	if(i !== -1){
	this.institutes.splice(i,1);
	}
	   if(this.institutes.length < 2){
       MENU_ITEMS[2].hidden = true;
       MENU_ITEMS[3].hidden = true;
       MENU_ITEMS[4].hidden = true;
     }
}
confirm(value:boolean){
  this.confirmDelete = value;
}
}
