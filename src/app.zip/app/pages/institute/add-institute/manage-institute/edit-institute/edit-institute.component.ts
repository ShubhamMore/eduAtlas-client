import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators, FormArray} from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
import {ApiService} from '../../../../../services/api.service';
import {CountryService} from '../../../../../services/country.service';
@Component({
  selector: 'ngx-edit-institute',
  templateUrl: './edit-institute.component.html',
  styleUrls: ['./edit-institute.component.scss']
})
export class EditInstituteComponent implements OnInit {

  updateInstitute:FormGroup;
  submitted = false;
  inputValue:string;
  routerId:string;
  instituteData:any;
  instituteUpdate:any;
    stateInfo:any[] = [];
  countryInfo:any[] = [];
  cityInfo:any[] = [];
  user:any;
  states= ['Delhi','Haryana','Punjab','UP','Bihar','Maharashtra','Banglore','MP','Assam'];
  city = [
    {
      delhi:['Janakpuri','Uttam Nagar','Nangloi','Palam','Rohini']
    },
    {
      haryana:['Rohtak','Faridabad','Patel Nagar','Jhajjar','Sohna','Basai']
    }
  
  ]
  category=[
    {id:1,name:'Pre School'},
    {id:2,name:'School'},
    {id:3,name:'Tuition Centers'},
    {id:4,name:'Coaching Centers'},
    {id:5,name:'Hobby Centers'},
    {id:6,name:'Enhanced learning'},
    {id:7,name:'Sports Centers'},
   
  ]
    constructor(private fb:FormBuilder,private api:ApiService, 
      private active:ActivatedRoute, private router:Router, private country: CountryService) { }
  
    ngOnInit() {
      this.updateInstitute = this.fb.group({
       id:[''],
        name:['',Validators.required],
        address: this.fb.group({
          addressLine:[''],
          locality:[''],
          city:[''],
          state:[''],
          pincode:[null]
        }),
        googleMap:[''],
        contact:['',Validators.compose([Validators.required,Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/)])],
        category:[[]],
        instituteMetaTag:this.fb.array([
          this.fb.control('')
        ]),
        logo:['']
      });
     this.routerId = this.active.snapshot.paramMap.get('id');
     this.api.getInstitute(this.routerId)
     	.subscribe(data => {
     		  this.instituteData = JSON.parse(JSON.stringify(data));
           this.instituteUpdate = this.instituteData.institute
     		console.log(this.instituteUpdate);
     

     this.updateInstitute.patchValue({
   
     	name:this.instituteUpdate.basicInfo.name,
     	contact:this.instituteUpdate.basicInfo.contactNumber,
     	address:{
     		addressLine:this.instituteUpdate.address.addressLine,
     		locality:this.instituteUpdate.address.locality,
     		city:this.instituteUpdate.address.city,
     		state:this.instituteUpdate.address.state,
     		pincode:this.instituteUpdate.address.pincode,
     	},
     
     	category:this.instituteUpdate.category,
       instituteMetaTag:this.instituteUpdate.instituteMetaTag
     })
	});
       this.getCountries()
    }

      getCountries(){
      this.country.allCountries().subscribe(
        data => {
          this.countryInfo = data.Countries
              this.stateInfo = this.countryInfo[100].States;
              this.cityInfo = this.stateInfo[0].Cities;
              console.log(this.stateInfo);
              console.log(this.cityInfo)
        },
        err => console.log(err),
        () => console.log('complete')
        )
    }

      onChangeState(stateValue){
     
      this.cityInfo = this.stateInfo[stateValue].Cities;
    console.log(this.cityInfo)
    }

    get instituteMetaTag(){
      return this.updateInstitute.get('instituteMetaTag') as FormArray;
    }
    addMetaTag(){
      this.instituteMetaTag.push(this.fb.control(''));
    }
    get f(){
      return this.updateInstitute.controls;
    }
  onSubmit(){

    this.submitted = true
    console.log(this.f.contact.errors)
    if(this.updateInstitute.invalid){
      return
    }
   
 	this.api.updateInstitute(this.routerId, this.updateInstitute.value)
 		.subscribe((data)=>{
 			console.log('success update' + JSON.stringify(data))

 		},err => console.log(err));
 		// this.router.navigate(['/pages/institute/manage-institute']);

  }
  }
