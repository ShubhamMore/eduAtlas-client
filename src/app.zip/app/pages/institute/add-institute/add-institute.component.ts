import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators, FormArray} from '@angular/forms';
import {Title,Meta} from '@angular/platform-browser'
import {ApiService} from '../../../services/api.service';
import {CountryService} from '../../../services/country.service'
import {NbDialogService} from '@nebular/theme'
import {MENU_ITEMS} from '../../pages-menu';
import {InstAddDialogComponent} from './inst-add-dialog/inst-add-dialog.component'
@Component({
  selector: 'ngx-add-institute',
  templateUrl: './add-institute.component.html',
  styleUrls: ['./add-institute.component.scss']
})
export class AddInstituteComponent implements OnInit {
  institute:FormGroup;
  submitted = false;
  inputValue:string;
  id:number = 0;
  imagePreview: string;
  user:any;
  stateInfo:any[] = [];
  countryInfo:any[] = [];
  cityInfo:any[] = [];
  states= ['Delhi','Haryana','Punjab','UP','Bihar','Maharashtra','Banglore','MP','Assam'];
  city = [
    {
      delhi:['Janakpuri','Uttam Nagar','Nangloi','Palam','Rohini']
    },
    {
      haryana:['Rohtak','Faridabad','Patel Nagar','Jhajjar','Sohna','Basai']
    }
  
  ]
  category=[
    {id:1,name:'Pre School'},
    {id:2,name:'School'},
    {id:3,name:'Tuition Centers'},
    {id:4,name:'Coaching Centers'},
    {id:5,name:'Hobby Centers'},
    {id:6,name:'Enhanced learning'},
    {id:7,name:'Sports Centers'},
   
  ]
    constructor(private fb:FormBuilder,private api:ApiService,private country:CountryService, private dialog:NbDialogService) { }
  
    ngOnInit() {
 

      this.institute = this.fb.group({
        id:[this.id++],
        name:['',Validators.required],
        address: this.fb.group({
          addressLine:[''],
          locality:[''],
          city:[''],
          state:[''],
          pincode:[null]
        }),
        googleMap:[''],
        contact:['',Validators.compose([Validators.required,Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/)])],
        category:[[]],
        instituteMetaTag:this.fb.array([
          this.fb.control('')
        ]),
        logo:[null]
      });
       MENU_ITEMS[2].hidden = true;
       MENU_ITEMS[3].hidden = true;
       MENU_ITEMS[4].hidden = true;

       this.getCountries();
     
    }
    onImagePicked(event: Event) {
      const file = (event.target as HTMLInputElement).files[0];
      this.institute.patchValue({logo: file});
      this.institute.get('logo').updateValueAndValidity();
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result as string;
      };
      reader.readAsDataURL(file);
     
    }
    getCountries(){
      this.country.allCountries().subscribe(
        data => {
          this.countryInfo = data.Countries
              this.stateInfo = this.countryInfo[100].States;
              this.cityInfo = this.stateInfo[0].Cities;
              
        },
        err => console.log(err),
        () => console.log('complete')
        )
    }
  
     
  
    onChangeState(stateValue){
      this.cityInfo = this.stateInfo[stateValue].Cities;
    
    }



    get instituteMetaTag(){
      return this.institute.get('instituteMetaTag') as FormArray;
    }
    addMetaTag(){
      this.instituteMetaTag.push(this.fb.control(''));
    }
    get f(){
      return this.institute.controls;
    }
  onSubmit(){

   
    this.submitted = true
    // console.log(this.f.contact.errors)
    if(this.institute.invalid){
      return
    }
    console.log(this.institute.value);
    this.api.addInstitute(this.institute.value)
      .subscribe(data => {
        this.user = data;
        console.log(this.user);
      })
 this.institute.reset(this.institute.value);
    this.dialog.open(InstAddDialogComponent, {
      context: {
        title: 'Institute Successfully Added',
      },
    });

   
  }
  change(event){
    console.log(event.target.value)
  
  }
  }
  
