import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators} from '@angular/forms'
@Component({
  selector: 'ngx-branch-conf',
  templateUrl: './branch-conf.component.html',
  styleUrls: ['./branch-conf.component.scss']
})
export class BranchConfComponent implements OnInit {
  branch:FormGroup

    constructor(private fb:FormBuilder) { }
  
    ngOnInit() {
      this.branch = this.fb.group({
      addCourse:this.fb.group({
        courseName:['',Validators.required],
        courseCode:['',Validators.required],
        courseFees:['',Validators.required],
        toggleGST:this.fb.group({
          toggleInclusive:['']
        }),
        description:[''],
        totalFee:[''],
        edit:['']
      }),
      addBatches:{
        parentCourse:{batch1:{
            code:[''],
            description:['']
          }
        },
        discount:this.fb.group({
          code:[''],
          description:[''],
          amount:['']
        }),
        receiptConfig:this.fb.group({
          businessName:[''],
          address:[''],
          gstNo:[''],
          termsAndCondition:[''],
          toggleCollection:['']
        }),
        roleManagement:this.fb.group({
          instituteRole:{
            emailId:'',
            role:{brachManager:'',Teacher:''}
          },
          counselor:{enrolment:'',CRM:''}
        })
      },

    })
    
  }
  get f(){
    return this.branch.controls;
  }
  onSubmit(){
    console.log(this.branch.value)
  }
}