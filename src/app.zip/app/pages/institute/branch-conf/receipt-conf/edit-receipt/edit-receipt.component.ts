import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import{ApiService} from '../../../../../services/api.service'
import {ActivatedRoute,Router} from '@angular/router'

@Component({
  selector: 'ngx-edit-receipt',
  templateUrl: './edit-receipt.component.html',
  styleUrls: ['./edit-receipt.component.scss']
})
export class EditReceiptComponent implements OnInit {
receipt:FormGroup;
submitted = false;
routerId:number;
fees=['Collection Basis','Course Fee Basis']
  constructor(private fb:FormBuilder,private api:ApiService,private active:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.receipt = this.fb.group({
    	id:[],
      businessName:['',Validators.required],
      address:['',Validators.required],
      gstNo:[''],
      termsAndCondtions:['',Validators.required],
      fee:['',Validators.required]
    });
    this.routerId = +this.active.snapshot.paramMap.get('id');
    this.api.getReceipt(this.routerId).subscribe(data => {
    	this.receipt.patchValue({
    		id:data.id,
    		businessName:data.businessName,
    		address:data.address,
    		gstNo:data.gstNo,
    		termsAndCondtions:data.termsAndCondtions,
    		fee:data.fee
    	})
    })
  }
  get f(){
   return this.receipt.controls;
  }
onSubmit(){
  this.submitted = true;
  if(this.receipt.invalid){
    return
  }
  this.api.updateReceipt(this.receipt.value).subscribe(
  	()=>console.log('update success'),
  	err => console.error(err)
  	);
  this.router.navigate(['/pages/institute/branch-config/manage-receipt']);
}
}

