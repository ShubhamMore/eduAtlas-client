import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../../../../services/api.service';
import {Router} from '@angular/router';
@Component({
  selector: 'ngx-manage-receipt',
  templateUrl: './manage-receipt.component.html',
  styleUrls: ['./manage-receipt.component.scss']
})
export class ManageReceiptComponent implements OnInit {
receipts:any[]=[];
  constructor(private api:ApiService,private router:Router) { }

  ngOnInit() {
  	this.getReceipts();
  }
  getReceipts(){
  	this.api.getReceipts().subscribe(data => {
  		this.receipts = data;
  	});
  }

  edit(id:number){
  	this.router.navigate(['/pages/institute/branch-config/edit-receipt',id]);
  }
  delete(id:number){
  	this.api.deleteReceipt(id).subscribe(
  		() => console.log('delete success'),
  		err => console.error(err)

  		);
  	const i = this.receipts.findIndex(e => e.id == id)
	if(i !== -1){
	this.receipts.splice(i,1);
	}
  }
}

