import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import{ApiService} from '../../../../services/api.service'

@Component({
  selector: 'ngx-receipt-conf',
  templateUrl: './receipt-conf.component.html',
  styleUrls: ['./receipt-conf.component.scss']
})
export class ReceiptConfComponent implements OnInit {
receipt:FormGroup;
submitted = false;
id=0;
fees=['Collection Basis','Course Fee Basis']
  constructor(private fb:FormBuilder,private api:ApiService) { }

  ngOnInit() {
    this.receipt = this.fb.group({
      id:[this.id++],
      businessName:['',Validators.required],
      address:['',Validators.required],
      gstNo:[''],
      termsAndCondtions:['',Validators.required],
      fee:['',Validators.required]
    })
  }
  get f(){
   return this.receipt.controls;
  }
onSubmit(){
  this.submitted = true;
  if(this.receipt.invalid){
    return
  }
  this.api.addReceipt(this.receipt.value).subscribe(
    ()=>console.log('update success'),
    err=>console.error(err)
    );
  
}
}
