import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../../../../services/api.service';
import {courseData} from 'assets/dataTypes/dataType'
import {ActivatedRoute,Router} from '@angular/router';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
@Component({
  selector: 'ngx-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.scss']
})
export class EditCourseComponent implements OnInit {
course:FormGroup;
submitted = false;
routerId:number;
updateCourse:any;
  constructor(private fb:FormBuilder,private api:ApiService,private active:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.course = this.fb.group({
      id:[],
        name:['',Validators.required],
        code:['',Validators.required],
        fees:[''],
        gst:[''],
        discription:[''],
        totalFee:['']
      });
    this.routerId = +this.active.snapshot.paramMap.get('id');
    this.api.getCourse(this.routerId).subscribe(data => {
    	this.updateCourse = data;

       this.course.patchValue({
    	id:this.updateCourse.id,
    	name:this.updateCourse.name,
    	code:this.updateCourse.code,
    	fees:this.updateCourse.fees,
    	gst:this.updateCourse.gst,
    	discription:this.updateCourse.discription,
    	totalFee:this.updateCourse.totalFee
    });
    });  
 
  }
  get f(){
    return this.course.controls;
  }
onSubmit(){
  this.submitted = true;
if(this.course.invalid){
  return
}
console.log(this.course.value);
this.api.updateCourse(this.course.value)
	.subscribe((data)=>console.log(data));
	this.router.navigate(['/pages/institute/branch-config/manage-course']);
}
}
