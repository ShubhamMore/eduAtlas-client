import { Component, OnInit } from '@angular/core';
import {courseData} from 'assets/dataTypes/dataType';
import {ApiService} from '../../../../../services/api.service';
import {Router} from '@angular/router';
@Component({
  selector: 'ngx-manage-course',
  templateUrl: './manage-course.component.html',
  styleUrls: ['./manage-course.component.scss']
})
export class ManageCourseComponent implements OnInit {
courses:courseData[];
  constructor(private api:ApiService,private router:Router) { }

  ngOnInit() {
  	this.getCourses();
  }
getCourses(){
	this.api.getCourses().subscribe(data => {
		console.log(data)
		this.courses = data;
	});
}

view(id:number){
this.router.navigate(['/pages/institute/branch-config/view-course',id])
}
edit(id:number){
	this.router.navigate(['/pages/institute/branch-config/edit-course',id])
}
delete(id:number){
this.api.deleteCourse(id).subscribe(
	()=>console.log('successfully delete'),
	err=>console.error(err)
	)
const i = this.courses.findIndex(e => e.id == id)
	if(i !== -1){
	this.courses.splice(i,1);
	}
}
}
