import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators} from '@angular/forms';
import {ApiService} from '../../../../services/api.service';

@Component({
  selector: 'ngx-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.scss']
})
export class AddCourseComponent implements OnInit {
course:FormGroup;
submitted = false;
id:number = 0;
  constructor(private fb:FormBuilder,private api:ApiService) { }

  ngOnInit() {
    this.course = this.fb.group({
      id:[this.id++],
        name:['',Validators.required],
        code:['',Validators.required],
        fees:[''],
        gst:[''],
        discription:[''],
        totalFee:['']
      })
      
  }
  get f(){
    return this.course.controls;
  }
onSubmit(){
  this.submitted = true;
if(this.course.invalid){
  return
}
console.log(this.course.value);
this.api.addCourse(this.course.value).subscribe(
  data=>{console.log(data)},
  err=>console.error(err));
}
}
