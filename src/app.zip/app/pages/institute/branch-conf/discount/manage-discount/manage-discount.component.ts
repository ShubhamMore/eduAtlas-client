import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../../../../services/api.service';
import {discountData} from 'assets/dataTypes/dataType';
import {Router} from '@angular/router';
@Component({
  selector: 'ngx-manage-discount',
  templateUrl: './manage-discount.component.html',
  styleUrls: ['./manage-discount.component.scss']
})
export class ManageDiscountComponent implements OnInit {
discounts:discountData[]=[];
  constructor(private api:ApiService,private router:Router) { }

  ngOnInit() {
  	this.getDiscounts();
  }
  getDiscounts(){
  	this.api.getDiscounts().subscribe(data => {
  		console.log(data);
  		this.discounts = data
  	},
err => console.error(err)
  	)
  };

  edit(id:number){
  	this.router.navigate(['/pages/institute/branch-config/edit-discount',id]);
  }

 delete(id:number){
this.api.deleteDiscount(id).subscribe(
	()=>console.log('successfully deleted'),
	err=>console.error(err)
	)
const i = this.discounts.findIndex(e => e.id == id)
	if(i !== -1){
	this.discounts.splice(i,1);
	}
}
}
