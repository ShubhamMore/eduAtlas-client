import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {ApiService} from '../../../../services/api.service';

@Component({
  selector: 'ngx-discount',
  templateUrl: './discount.component.html',
  styleUrls: ['./discount.component.scss']
})
export class DiscountComponent implements OnInit {
discount:FormGroup
id=0;
submitted = false
  constructor(private fb:FormBuilder,private api:ApiService) { }

  ngOnInit() {
    this.discount = this.fb.group({
      id:[this.id++],
      code:['',Validators.required],
      discription:[''],
      amount:['',Validators.required]
    })
  }
  get f(){
    return this.discount.controls;
  }
  onSubmit(){
    this.submitted = true
    if(this.discount.invalid){
      return
    }
    this.api.addDiscount(this.discount.value).subscribe(
      data => console.log('add success'+' '+data),
      err=>console.error(err)
      );
   
  }
}
