import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {ApiService} from '../../../../../services/api.service';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'ngx-edit-discount',
  templateUrl: './edit-discount.component.html',
  styleUrls: ['./edit-discount.component.scss']
})
export class EditDiscountComponent implements OnInit {
discount:FormGroup
submitted = false
routerId:number;
dis:any;
  constructor(private fb:FormBuilder,private api:ApiService,private router:Router,private active:ActivatedRoute) { }

  ngOnInit() {
    this.discount = this.fb.group({
    	id:[],
      code:['',Validators.required],
      discription:[''],
      amount:['',Validators.required]
    })
    this.routerId = +this.active.snapshot.paramMap.get('id');
    this.api.getDiscount(this.routerId).subscribe(
    	data =>{
    		this.dis = data
    		this.discount.patchValue({
    			id:data.id,
    			code:data.code,
    			discription:data.discription,
    			amount:data.amount
    		})	
    	},
    	err => console.error(err)
    	)
  }
  get f(){
    return this.discount.controls;
  }
  onSubmit(){
    this.submitted = true
    if(this.discount.invalid){
      return
    }
    this.api.updateDiscount(this.discount.value)
    	.subscribe(() => console.log('update success'),
				err=>console.error(err)
    		);
   this.router.navigate(['/pages/institute/branch-config/manage-discount']);
  }
}

