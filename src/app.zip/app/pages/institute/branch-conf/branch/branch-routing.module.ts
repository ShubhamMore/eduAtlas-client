import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BranchConfComponent } from '../branch-conf.component';
import { AddCourseComponent } from '../add-course/add-course.component';
import { AddBatchesComponent } from '../add-batches/add-batches.component';
import { RoleManagementComponent } from '../role-management/role-management.component';
import { DiscountComponent } from '../discount/discount.component';
import { ReceiptConfComponent } from '../receipt-conf/receipt-conf.component';
import {ManageCourseComponent} from '../../branch-conf/add-course/manage-course/manage-course.component';
import {ViewCourseComponent} from '../../branch-conf/add-course/view-course/view-course.component';
import {EditCourseComponent} from '../../branch-conf/add-course/edit-course/edit-course.component';
import {ManageBatchComponent} from '../add-batches/manage-batch/manage-batch.component';
import {EditBatchComponent} from '../add-batches/edit-batch/edit-batch.component';
import {ManageDiscountComponent} from '../discount/manage-discount/manage-discount.component';
import {EditDiscountComponent} from '../discount/edit-discount/edit-discount.component';
import {ManageReceiptComponent} from '../../branch-conf/receipt-conf/manage-receipt/manage-receipt.component'
import {EditReceiptComponent} from '../../branch-conf/receipt-conf/edit-receipt/edit-receipt.component'
const routes = [
    {path:'',component:BranchConfComponent,
    children:[
      {path:'add-courses',component:AddCourseComponent},
      {path:'manage-course',component:ManageCourseComponent},
      {path:'view-course/:id',component:ViewCourseComponent},
      {path:'edit-course/:id',component:EditCourseComponent},
      {path:'add-batches',component:AddBatchesComponent},
      {path:'manage-batch',component:ManageBatchComponent},
      {path:'edit-batch/:id',component:EditBatchComponent},
      {path:'discount',component:DiscountComponent},
      {path:'manage-discount',component:ManageDiscountComponent},
      {path:'edit-discount/:id',component:EditDiscountComponent},
      {path:'manage-receipt',component:ManageReceiptComponent},
      {path:'edit-receipt/:id',component:EditReceiptComponent},
      {path:'receipt-conf',component:ReceiptConfComponent},
      {path:'role-management',component:RoleManagementComponent},  

      {path:'', redirectTo:'add-courses',pathMatch:'full'}
    ]
    

    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
  })
  export class BranchRoutingModule {
  }
  