import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NbComponentSize } from '@nebular/theme';

@Component({
  selector: 'ngx-role-management',
  templateUrl: './role-management.component.html',
  styleUrls: ['./role-management.component.scss']
})
export class RoleManagementComponent implements OnInit {
roleManage:FormGroup;
submitted = false;
selectedSize:NbComponentSize = 'medium'
  constructor(private fb:FormBuilder) { }

  ngOnInit() {
    this.roleManage = this.fb.group({
      email:['',Validators.required],
      role:this.fb.group({
        branchManger:[''],
        teacher:[''],
        counselor:{
          enrolment:[''],
          crm:['']
        }
      }),


    })
  }
  get f(){
    return this.roleManage.controls
  }
onSubmit(){
this.submitted = true
  if(this.roleManage.invalid){
    return
  }
  console.log(this.roleManage.value)
}
}
