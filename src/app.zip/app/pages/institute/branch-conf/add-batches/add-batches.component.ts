import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {ApiService} from '../../../../services/api.service';
@Component({
  selector: 'ngx-add-batches',
  templateUrl: './add-batches.component.html',
  styleUrls: ['./add-batches.component.scss']
})
export class AddBatchesComponent implements OnInit {
parentCourse=['course1','course2','course3'];
linearMode = true;
batch:FormGroup;
submitted = false;
id=0;
  constructor(private fb:FormBuilder,private api:ApiService) { }
 
  ngOnInit() {
    this.batch = this.fb.group({
      id:[this.id++],
      course:['',Validators.required],
      code:['',Validators.required],
      discription:['']
    })
  }
  get f(){
    return this.batch.controls
  }
 onSubmit(){
   this.submitted = true;
   console.log(this.f.code.errors)
   if(this.batch.invalid){

     return
   }
   console.log(this.batch.value)
   this.api.addBatch(this.batch.value).subscribe(
     ()=>console.log('successfully added'),
     err=>console.error(err)
     );
 }
}