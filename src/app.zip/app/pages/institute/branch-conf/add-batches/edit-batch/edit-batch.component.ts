import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {ApiService} from '../../../../../services/api.service';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
@Component({
  selector: 'ngx-edit-batch',
  templateUrl: './edit-batch.component.html',
  styleUrls: ['./edit-batch.component.scss']
})
export class EditBatchComponent implements OnInit {
routerId:number
updateBatch:any
batch:FormGroup;
submitted = false;
parentCourse=['course1','course2','course3'];
  constructor(private active:ActivatedRoute,private api:ApiService,private fb:FormBuilder,private router:Router) { }

  ngOnInit() {
  	 this.batch = this.fb.group({
  	  id:[],
      course:['',Validators.required],
      code:['',Validators.required],
      discription:['']
    })
  	this.routerId = +this.active.snapshot.paramMap.get('id');
  	this.api.getBatch(this.routerId).subscribe(data=>{
  		this.updateBatch = data;
  	

  	this.batch.patchValue({
  		id:this.updateBatch.id,
  		course:this.updateBatch.course,
  		code:this.updateBatch.code,
  		discription:this.updateBatch.discription
  	})	
  	});
  }
 get f(){
    return this.batch.controls
  }
 onSubmit(){
   this.submitted = true;
   console.log(this.f.code.errors)
   if(this.batch.invalid){

     return
   }
   console.log(this.batch.value);
  this.api.updateBatch(this.batch.value)
	.subscribe((data)=>console.log(data));
	this.router.navigate(['/pages/institute/branch-config/manage-batch']);
   
 }
}
