import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../../../../services/api.service';
import {batchData} from 'assets/dataTypes/dataType';
import {Router} from '@angular/router';
@Component({
  selector: 'ngx-manage-batch',
  templateUrl: './manage-batch.component.html',
  styleUrls: ['./manage-batch.component.scss']
})
export class ManageBatchComponent implements OnInit {
batch:batchData[];	
  constructor(private api:ApiService, private router:Router) { }

  ngOnInit() {
  this.getBatches()
  }
getBatches(){
	this.api.getBatches().subscribe(data => {
		console.log(data);
		this.batch = data;
	});
}
edit(id:number){
this.router.navigate(['/pages/institute/branch-config/edit-batch',id])
}
delete(id:number){
this.api.deleteBatch(id).subscribe(
	()=>console.log('successfully delete'),
	err=>console.error(err)
	)
const i = this.batch.findIndex(e => e.id == id)
	if(i !== -1){
	this.batch.splice(i,1);
	}
}
}
