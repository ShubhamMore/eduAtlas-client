import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InstRoutingModule } from './institute-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NbCardModule, NbLayoutModule, NbInputModule, NbSelectModule, NbButtonModule, NbAccordionComponent, NbAccordionItemBodyComponent, NbAccordionItemHeaderComponent, NbAccordionModule } from '@nebular/theme';
import { AddInstituteComponent } from '../add-institute/add-institute.component';
import { InstituteComponent } from '../institute.component';
import { AddStudentsComponent } from '../add-students/add-students.component';
import { BranchConfComponent } from '../branch-conf/branch-conf.component';

import {ManageStudentsComponent} from '../add-students/manage-students/manage-students.component';
import {ManageInstituteComponent} from '../add-institute/manage-institute/manage-institute.component'
import {ViewInstituteComponent} from '../add-institute/manage-institute/view-institute/view-institute.component';
import {EditInstituteComponent} from '../add-institute/manage-institute/edit-institute/edit-institute.component';
import {ViewStudentComponent} from '../add-students/manage-students/view-student/view-student.component';
import {EditStudentComponent} from '../add-students/manage-students/edit-student/edit-student.component'

@NgModule({
  declarations: [AddInstituteComponent,
      InstituteComponent,
      AddStudentsComponent,
  
     ManageStudentsComponent,
     ManageInstituteComponent,
     ViewInstituteComponent,
     EditInstituteComponent,
     ViewStudentComponent,
     EditStudentComponent
 
    ],
  imports: [
    CommonModule,
    InstRoutingModule,
    ReactiveFormsModule,
    NbCardModule,
    NbLayoutModule,
    NbInputModule,
    NbSelectModule,
    NbButtonModule,
    NbAccordionModule
  ]
})
export class InstituteModule { }
