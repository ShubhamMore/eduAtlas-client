import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { InstituteComponent } from '../institute.component';
import { AddInstituteComponent } from '../add-institute/add-institute.component';
import { AddStudentsComponent } from '../add-students/add-students.component';
import { BranchConfComponent } from '../branch-conf/branch-conf.component';
import {ManageInstituteComponent} from '../add-institute/manage-institute/manage-institute.component';
import {ManageStudentsComponent} from '../add-students/manage-students/manage-students.component';
import {ViewInstituteComponent} from '../add-institute/manage-institute/view-institute/view-institute.component';
import {EditInstituteComponent} from '../add-institute/manage-institute/edit-institute/edit-institute.component';
import {ViewStudentComponent} from '../add-students/manage-students/view-student/view-student.component'
import {EditStudentComponent} from '../add-students/manage-students/edit-student/edit-student.component';

const routes:Routes = [
    {
        path:'',component:InstituteComponent,
        children:[
            {path:'add-institute',component:AddInstituteComponent},
            {path:'add-students',component:AddStudentsComponent},
            {path:'manage-institute',component:ManageInstituteComponent},
            {path:'manage-students',component:ManageStudentsComponent},
            {path:'manage-institute',component:ManageInstituteComponent
              
            },
            {path:'view-institute/:id',component:ViewInstituteComponent},
            {path:'edit-institute/:id',component:EditInstituteComponent},
            {path:'view-student/:id',component:ViewStudentComponent},
            {path:'edit-student/:id',component:EditStudentComponent},
       
            {
              path: 'branch-config',
              loadChildren: () => import('../branch-conf/branch/branch.module')
                .then(m => m.BranchModule),
                
            },
      
        ]
    },
    
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
  })
  export class InstRoutingModule {
  }
  