import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../../../services/api.service'
import {studentsData} from '../../../../../assets/dataTypes/dataType';
import {Router} from '@angular/router';
@Component({
  selector: 'ngx-manage-students',
  templateUrl: './manage-students.component.html',
  styleUrls: ['./manage-students.component.scss']
})
export class ManageStudentsComponent implements OnInit {
students:studentsData[]=[];
  constructor(private api:ApiService,private router:Router) { }

  ngOnInit() {
  	this.getStudents()
  }
getStudents(){
	this.api.getStudents().subscribe(data => {
		console.log(data);
		this.students = data;
	});
}
view(id:number){

this.router.navigate(['/pages/institute/view-student',id]);
}
edit(id:number){
	this.router.navigate(['/pages/institute/edit-student',id]);
}
delete(id:number){
	this.api.deleteStudent(id)
	.subscribe(()=>console.log('success delete' + id))
		const i = this.students.findIndex(e => e.id == id)
	if(i !== -1){
	this.students.splice(i,1);
	}
}
}
