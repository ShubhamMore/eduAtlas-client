import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../../../../services/api.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'ngx-view-student',
  templateUrl: './view-student.component.html',
  styleUrls: ['./view-student.component.scss']
})
export class ViewStudentComponent implements OnInit {
student:any;
routerId:number;
  constructor(private api:ApiService,private active:ActivatedRoute) { }

  ngOnInit() {
  	this.routerId = +this.active.snapshot.paramMap.get('id');
  	this.getStudent(this.routerId);
  }
getStudent(id:number){
	this.api.getStudent(id).subscribe(data => {
		this.student = data;
		console.log(data)
	})
}
}
