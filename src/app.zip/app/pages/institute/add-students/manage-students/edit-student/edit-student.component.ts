import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators} from '@angular/forms'
import {ApiService} from '../../../../../services/api.service';
import {Router,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'ngx-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.scss']
})
export class EditStudentComponent implements OnInit {

  students:FormGroup;
  routerId:number;
  student:any;
  submitted = false;
  modes=['Cash','Chaque/DD','Card','Others'];
  selectItem='1'
  mode=[
    {id:1,name:['Cash',[]]},
    {
      id:2,name:[
        'Chaque/DD',
        [
          {id:1,name:'Bank Name'},
          {id:2,name:'Date'},
          {id:3,name:'Instalment No.'}
        ]
      ]
    },
    {
      id:3,name:[
        'Card',
        [
          {id:1,name:'Bank Name'},
          {id:2,name:'Transaction Id'}
        ]
      ]
    },
    {
      id:4,name:[
        'Others',
        [
          {id:1,name:'Mode Name'},
          {id:2,name:'Transaction Id'}
        ]
      ]
    }
  ]
    constructor(private fb:FormBuilder, private api:ApiService,private router:Router, private active:ActivatedRoute) { }
  
    ngOnInit() {
      this.students = this.fb.group({
        id:[''],
        name:['',Validators.required],
      rollNo:['',Validators.required],
      email:['',Validators.compose([Validators.required,Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)])],
        
        contact:['',Validators.compose([Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/)])],
        parentName:[''],
        parentContact:['',Validators.compose([Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/)])],
        parentEmail:['',Validators.compose([Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)])],
        address:[''],
        courseDetails: this.fb.group({
          course:[''],
          branch:[''],
          discount:[''],
          additionalDiscount:[''],
          netPayable:['']
        }),
    
        feeDetails:this.fb.group({
          installments:[''],
          nextInstallment:[''],
          amountCollected:[''],
          modes:[''],
          mode:this.fb.group({
            cash:[false],
            chaque:this.fb.group({
              bankName:[''],
              date:[''],
              instalmentNo:['']
            }),
            card:this.fb.group({
              bankName:[''],
              transactionID:['']
            }),
            others:this.fb.group({
              modeName:[''],
              transactionID:['']
            })

          }),
          
        }),
        materialRecord:['']
      });
      // console.log(this.mode[1].name)
       this.routerId = +this.active.snapshot.paramMap.get('id');

      this.api.getStudent(this.routerId).subscribe(data => {
      	this.student = data;
      	console.log(this.student);

     
      this.students.patchValue({
      	id:this.student.id,
      	name:this.student.name,
      	rollNo:this.student.rollNo,
      	email:this.student.email,
      	contact:this.student.contact,
      	parentName:this.student.parentName,
      	parentEmail:this.student.parentEmail,
      	parentContact:this.student.parentContact,
      	address:this.student.address,
      	courseDetails:{
      		course:this.student.courseDetails.couse,
	      	branch:this.student.courseDetails.branch,
	      	discount:this.student.courseDetails.discount,
	      	additionalDiscount:this.student.courseDetails.additionalDiscount,
	      	netPayable:this.student.netPayable,
      	},
      	
      	materialRecord:this.student.materialRecord
      });
      // this.students.value.courseDetails.patchValue({
      // 	course:this.student.courseDetails.couse,
      // 	branch:this.student.courseDetails.branch,
      // 	discount:this.student.courseDetails.discount,
      // 	additionalDiscount:this.student.courseDetails.additionalDiscount,
      // 	netPayable:this.student.netPayable,
      	
      // });


    });
    }
  
    get f(){
      return this.students.controls;

    }
  onSubmit(){
    this.submitted = true;
    if(this.students.invalid){
      return
    }
    this.api.updateStudent(this.students.value)
    	.subscribe(() => console.log('successfully update'));
    this.router.navigate(['/pages/institute/manage-students']);	
  }
  }
  