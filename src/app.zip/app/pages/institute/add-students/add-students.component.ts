import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators} from '@angular/forms'
import {ApiService} from '../../../services/api.service';
@Component({
  selector: 'ngx-add-students',
  templateUrl: './add-students.component.html',
  styleUrls: ['./add-students.component.scss']
})
export class AddStudentsComponent implements OnInit {
  students:FormGroup;
  id:number = 0;
  submitted = false;
  modes=['Cash','Chaque/DD','Card','Others'];
  selectItem='1'
  mode=[
    {id:1,name:['Cash',[]]},
    {
      id:2,name:[
        'Chaque/DD',
        [
          {id:1,name:'Bank Name'},
          {id:2,name:'Date'},
          {id:3,name:'Instalment No.'}
        ]
      ]
    },
    {
      id:3,name:[
        'Card',
        [
          {id:1,name:'Bank Name'},
          {id:2,name:'Transaction Id'}
        ]
      ]
    },
    {
      id:4,name:[
        'Others',
        [
          {id:1,name:'Mode Name'},
          {id:2,name:'Transaction Id'}
        ]
      ]
    }
  ]
    constructor(private fb:FormBuilder, private api:ApiService) { }
  
    ngOnInit() {
      this.students = this.fb.group({
        id:[this.id++],
        name:['',Validators.required],
      rollNo:['',Validators.required],
      email:['',Validators.compose([Validators.required,Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)])],
        
        contact:['',Validators.compose([Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/)])],
        parentName:[''],
        parentContact:['',Validators.compose([Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/)])],
        parentEmail:['',Validators.compose([Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)])],
        address:[''],
        courseDetails: this.fb.group({
          course:[''],
          branch:[''],
          discount:[''],
          additionalDiscount:[''],
          netPayable:['']
        }),
    
        feeDetails:this.fb.group({
          installments:[''],
          nextInstallment:[''],
          amountCollected:[''],
          modes:[''],
          mode:this.fb.group({
            cash:[false],
            chaque:this.fb.group({
              bankName:[''],
              date:[''],
              instalmentNo:['']
            }),
            card:this.fb.group({
              bankName:[''],
              transactionID:['']
            }),
            others:this.fb.group({
              modeName:[''],
              transactionID:['']
            })

          }),
          
        }),
        materialRecord:['']
      });
      // console.log(this.mode[1].name)
    }
  
    get f(){
      return this.students.controls;

    }
  onSubmit(){
    this.submitted = true;
    if(this.students.invalid){
      return
    }
    console.log(this.students.value)
    this.api.addStudent(this.students.value).subscribe(data => {
      console.log(data);
    });
    
  }
  }
  