import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse,HttpHeaders} from '@angular/common/http';
import { catchError,tap,map } from 'rxjs/operators';
import { throwError, Observable, of } from 'rxjs';

import {batchData,discountData,courseData,studentsData,instituteData,receiptData} from '../../assets/dataTypes/dataType';
interface signupType{
  name:string;
  phonenumber:number;
  email:string;
  password:string;
 
}
@Injectable({
  providedIn: 'root'
})
export class ApiService {
 
  apiUrl = ['api/institute','api/students','api/course','api/batch','api/discount','api/receipt'];
  authToken = localStorage.getItem('token');
  //headers = new HttpHeaders().set('Content-Type','application/json').set('Accept','application/json');
  headers = new HttpHeaders().set('authorization', 'Bearer ' + this.authToken)
  httpOptions = {
    headers:this.headers
  };
  constructor(private http:HttpClient) { }
 
//=============================================INSTITUTE API=============================================================

  getInstitutes():Observable<any[]>{
    return this.http.get<any[]>('http://localhost:3000/institute/all', this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)

      );
  }
 getInstitute(id:string):Observable<any>{
   const url = `http://localhost:3000/institute/oneInstitute/${id}`;
   return this.http.get<instituteData>(url, this.httpOptions).pipe(
     tap(data => console.log(data)),
     catchError(this.handleError)
     );
 }

  // addInstitute(institute:instituteData):Observable<instituteData>{
  //   institute.id = null;
  //   return this.http.post<instituteData>(this.apiUrl[0],institute,this.httpOptions).pipe(
  //     tap(data => console.log(data)),
  //     catchError(this.handleError)
  //     );
  // }

  addInstitute(institute) {
    console.log('Institute - ', institute);
    const postData = new FormData();
    const data = {
      basicInfo: {
        name: institute.name,
        contactNumber: +institute.contact,
      },
      address: {
        addressLine:institute.address.addressLine,
        locality:institute.address.locality,
        state:institute.address.state,
        city:institute.address.city,
        pin:institute.address.pin
      },
      category: institute.category,
      metaTag: institute.instituteMetaTag
    };
    
    postData.append('basicInfo', JSON.stringify(data.basicInfo));
    postData.append('address', JSON.stringify(data.address));
    postData.append('metaTag', JSON.stringify(institute.instituteMetaTag));
    postData.append('category', JSON.stringify(institute.category));
    postData.append('logo',institute.logo, institute.name);
    return this.http.post<{message: string}>('http://localhost:3000/institute/addInstitute', postData, this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
    );
  }
  updateInstitute(id:string,institute:any):Observable<instituteData>{
    const url = `http://localhost:3000/institute/updateInstitute/${id}`;

    const data = {
      basicInfo: {
        name: institute.name,
        contactNumber: +institute.contact,
      },
      address: {
        addressLine:institute.address.addressLine,
        locality:institute.address.locality,
        state:institute.address.state,
        city:institute.address.city,
        pin:institute.address.pin
      },
      category: institute.category,
      metaTag: institute.instituteMetaTag
    };

    return this.http.put<{message:string}>(url,data,this.httpOptions).pipe(
      map(()=>institute),
      catchError(this.handleError)
      );
  }
 deleteInstitute(id:string):Observable<void>{
   const url = 'http://localhost:3000/institute/'+ id;
   return this.http.delete<void>(url,this.httpOptions).pipe(
     catchError(this.handleError)
     );
 }


//=====================================STUDENT API============================================================== 
 


  getStudents():Observable<studentsData[]>{
    return this.http.get<studentsData[]>(this.apiUrl[1]).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)

      );
  }
 getStudent(id:number):Observable<studentsData>{
   const url = `${this.apiUrl[1]}/${id}`;
   return this.http.get<studentsData>(url).pipe(
     catchError(this.handleError)
     );
 }

   addStudent(student):Observable<studentsData>{
    const postData = new FormData();
    const data = {
      instituteId:student.id,
      basicDetails:{
        name:student.name,
        rollNumber:student.rollNo,
        contactNumber:student.contact,
      },
      parentDetails:{
        name:student.parentName,
        contactNumber:student.parentContact
      }

    };
    
    return this.http.post<studentsData>(this.apiUrl[1],student,this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
      );
  }

  updateStudent(student:studentsData):Observable<studentsData>{
    const url = `${this.apiUrl[1]}/${student.id}`;
    return this.http.put<studentsData>(url,student,this.httpOptions).pipe(
      map(()=>student),
      catchError(this.handleError)
      );
  }

   deleteStudent(id:number):Observable<void>{
   const url = `${this.apiUrl[1]}/${id}`;
   return this.http.delete<void>(url,this.httpOptions).pipe(
     catchError(this.handleError)
     );
 }


//============================================COURSE API============================================================


 getCourses():Observable<courseData[]>{
   return this.http.get<courseData[]>(this.apiUrl[2]).pipe(
  tap((data)=>console.log(data)),
  catchError(this.handleError)
     );
 }
  addCourse(course:courseData):Observable<courseData>{
    course.id = null;
    return this.http.post<courseData>(this.apiUrl[2],course,this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
      );
  }

  getCourse(id:number):Observable<courseData>{
     const url = `${this.apiUrl[2]}/${id}`;
   return this.http.get<courseData>(url).pipe(
     catchError(this.handleError)
     );
  }
  updateCourse(course:courseData):Observable<courseData>{
    const url = `${this.apiUrl[2]}/${course.id}`;
    return this.http.put<courseData>(url,course,this.httpOptions).pipe(
      map(()=>course),
      catchError(this.handleError)
      );
  }
  deleteCourse(id:number):Observable<void>{
    const url = `${this.apiUrl[2]}/${id}`
    return this.http.delete<void>(url,this.httpOptions).pipe(
      catchError(this.handleError)
      );
  }


//============================================BATCHES API============================================================


  getBatches():Observable<batchData[]>{
    return this.http.get<batchData[]>(this.apiUrl[3]).pipe(
  tap(data => console.log(data)),
  catchError(this.handleError)
      );
  }
  getBatch(id:number):Observable<batchData>{
    const url = `${this.apiUrl[3]}/${id}`
    return this.http.get<batchData>(url).pipe(
      catchError(this.handleError)
      );
  }
  addBatch(batch:batchData):Observable<batchData>{
    batch.id = null;
    return this.http.post<batchData>(this.apiUrl[3],batch,this.httpOptions).pipe(
      tap(data=>console.log(data)),
      catchError(this.handleError)
      )
  }
  deleteBatch(id:number):Observable<void>{
    const url = `${this.apiUrl[3]}/${id}`
    return this.http.delete<void>(url,this.httpOptions).pipe(
catchError(this.handleError)
      );
  }
  updateBatch(batch:batchData):Observable<batchData>{
    const url = `${this.apiUrl[3]}/${batch.id}`;
    return this.http.put<courseData>(url,batch,this.httpOptions).pipe(
      map(()=>batch),
      catchError(this.handleError)
      );
  }


//============================================DISCOUNT API============================================================


 getDiscounts():Observable<discountData[]>{
    return this.http.get<discountData[]>(this.apiUrl[4]).pipe(
  tap(data => console.log(data)),
  catchError(this.handleError)
      );
  }
  getDiscount(id:number):Observable<discountData>{
    const url = `${this.apiUrl[4]}/${id}`;
    return this.http.get<discountData>(url).pipe(
catchError(this.handleError)
      );
  }

  addDiscount(discount:discountData):Observable<discountData>{
    discount.id = null;
    return this.http.post<discountData>(this.apiUrl[4],discount,this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
      );
  }

    deleteDiscount(id:number):Observable<void>{
    const url = `${this.apiUrl[4]}/${id}`
    return this.http.delete<void>(url,this.httpOptions).pipe(
catchError(this.handleError)
      );
  }
    updateDiscount(discount:discountData):Observable<discountData>{
    const url = `${this.apiUrl[4]}/${discount.id}`;
    return this.http.put<discountData>(url,discount,this.httpOptions).pipe(
      map(()=>discount),
      catchError(this.handleError)
      );
  }


//============================================RECEIPT API============================================================


 getReceipts():Observable<receiptData[]>{
    return this.http.get<receiptData[]>(this.apiUrl[5]).pipe(
  tap(data => console.log(data)),
  catchError(this.handleError)
      );
  }

    getReceipt(id:number):Observable<receiptData>{
    const url = `${this.apiUrl[5]}/${id}`;
    return this.http.get<receiptData>(url).pipe(
    catchError(this.handleError)
      );
  }

  addReceipt(receipt:receiptData):Observable<receiptData>{
    receipt.id = null;
    return this.http.post<receiptData>(this.apiUrl[5],receipt,this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
      );
  }
    updateReceipt(receipt:receiptData):Observable<receiptData>{
    const url = `${this.apiUrl[5]}/${receipt.id}`;
    return this.http.put<discountData>(url,receipt,this.httpOptions).pipe(
      map(()=>receipt),
      catchError(this.handleError)
      );
  }

    deleteReceipt(id:number):Observable<void>{
    const url = `${this.apiUrl[5]}/${id}`;
    return this.http.delete<void>(url,this.httpOptions).pipe(
    catchError(this.handleError)
      );
  }

  display(show:boolean){
    const display:boolean = show;
    return display;

  }
    // private handleError<T>(operation = 'operation', result?: T) {
  
  
  //   return (error: any): Observable<T> => {
  //     console.error(error);
  //     this.log(`${operation} failed: ${error.message}`);
  
  //     return of(result as T);
  //   };
  // }
  private handleError(error:any){
    console.log(error);
    return throwError(error);
  }  
  private log(message: string) {
    console.log(message);
  }
}
