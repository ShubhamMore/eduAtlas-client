import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

interface User{
	phone:number,
	password:string
}

interface signupType{
  name:string;
  phone:number;
  email:string;
  password:string;
 
}
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http:HttpClient) { }
  findUser(phone: number){
    return this.http.get<{User: any}>('http://localhost:3000/users/' + phone);
  }
  
  instituteLogin(user:User){
  	return this.http.post<{token: string, expireIn: number, phone: number}>('http://localhost:3000/users/login',user)
  }

  instituteSignup(signUp:signupType){
  	return this.http.post('http://localhost:3000/users/signup',signUp)
  }
}
