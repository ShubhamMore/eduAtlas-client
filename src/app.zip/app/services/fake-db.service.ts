import {InMemoryDbService} from 'angular-in-memory-web-api';

import {batchData,discountData,courseData,studentsData,receiptData,instituteData} from 'assets/dataTypes/dataType';

export class UserData implements InMemoryDbService {
  createDb(){
  	const institute: instituteData[]=[
  	{
  		id:0,iname:'',
  		address:{addressLine:'',locality:'',city:'',state:'',pin:0},
  		googleMap:'',icontact:'',icategory:['',''],iMetaTag:['','','']

  	}
  	];
    const students: studentsData[]=[
    {
      id:0,sname:'',roll:'',email:'',scontact:'',parentName:'',parentContact:'',
      parentEmail:'',address:'',course:'',batch:'',discount:'',addDiscount:'',
      netPayable:'',installments:'',nextInstallment:'',amtCollected:'',
      mode:'',materialRecord:''
    }
    ];
    const course:courseData[]=[
      {
        id:0,name:'',code:'',fees:'',gst:'',discription:'',totalFee:''
      }
    ];
    const batch:batchData[]=[
      {
       id:0, course:'',code:'',discription:''
      }
    ];
    const discount:discountData[]=[
      {
        id:0,code:'',amount:'',discription:''
      }
    ];
    const receipt:receiptData[]=[
    {
      id:0,businessName:'',address:'',gstNo:'',termsAndCondtions:'',fee:''
    }
    ];
  	return {institute,students,course,batch,discount,receipt};
  }
}