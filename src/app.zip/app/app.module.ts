/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CoreModule } from './@core/core.module';
import { ThemeModule } from './@theme/theme.module';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import {ApiService} from '../api.service'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';  
import {InMemoryWebApiModule} from 'angular-in-memory-web-api';
import {UserData} from './services/fake-db.service';
import {AuthInterceptor} from './services/auth-interceptor/auth-interceptor';

import {AuthGuard} from './auth.guard'
import {
  NbChatModule,
  NbDatepickerModule,
  NbDialogModule,
  NbMenuModule,
  NbSidebarModule,
  NbToastrModule,
  NbWindowModule,
  NbSelectModule,
  NbLayoutModule,
  NbCardModule,
  NbRadioModule
} from '@nebular/theme';
import { LoginComponent } from './admin/login/login.component';
import { SignUpComponent } from './admin/sign-up/sign-up.component';
import { OtpComponent } from './admin/otp/otp.component';
import { DialogComponent } from './admin/sign-up/dialog/dialog.component';
import { config } from 'rxjs';
import { LoginDialogComponent } from './admin/login/login-dialog/login-dialog.component';
import { SuccessComponent } from './admin/sign-up/success/success.component';
import { ForgetpasswordComponent } from './admin/forgetpassword/forgetpassword.component';
import {InstAddDialogComponent} from './pages/institute/add-institute/inst-add-dialog/inst-add-dialog.component'
// import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [AppComponent, LoginComponent, SignUpComponent, OtpComponent, DialogComponent, InstAddDialogComponent, LoginDialogComponent, SuccessComponent, ForgetpasswordComponent],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CommonModule,
    NbSelectModule,
    NbCardModule,
    NbLayoutModule,
    AppRoutingModule,
    NbRadioModule,
    //InMemoryWebApiModule.forRoot(UserData),
    ReactiveFormsModule,
    ThemeModule.forRoot(),
    NbSidebarModule.forRoot(),
    NbMenuModule.forRoot(),
    NbDatepickerModule.forRoot(),
    NbDialogModule.forRoot(),
    NbWindowModule.forRoot(),
    NbToastrModule.forRoot(),
    NbChatModule.forRoot({
      messageGoogleMapKey: 'AIzaSyA_wNuCzia92MAmdLRzmqitRGvCF7wCZPY',
    }),
    CoreModule.forRoot(),
  ],
  entryComponents: [
    DialogComponent,
    LoginDialogComponent,
    SuccessComponent,
    InstAddDialogComponent
 ],
  bootstrap: [AppComponent],
  providers:[
    ApiService,AuthGuard,
    //{provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
  ]
})
export class AppModule {
}
