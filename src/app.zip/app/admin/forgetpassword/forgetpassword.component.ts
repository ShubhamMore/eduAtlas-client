import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.scss']
})
export class ForgetpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
