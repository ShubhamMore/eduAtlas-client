import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'ngx-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss']
})
export class OtpComponent implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }
  otp

onOtp(){

  localStorage.setItem("otp",this.otp)
  
if(this.otp=="1234"){
  this.router.navigate(['/pages/home']);
}

else{
  alert("Invalid credential.Please try again...")
}
}
}