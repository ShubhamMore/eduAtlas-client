import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder, Validators, NgForm} from '@angular/forms';
import {MustMatch} from './_helpers/must-match.validator';
import {AuthService} from '../../services/auth.service';
import {Router} from '@angular/router';
import {DialogComponent} from './dialog/dialog.component'
import { NbDialogService } from '@nebular/theme';
import { SuccessComponent } from './success/success.component';
interface sendValue{
  name:string,
  email:string,
  phone:number,
  password:string,
  role:string
}

@Component({
  selector: 'ngx-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {
userExist:boolean;  
public registerUser:FormGroup
submitted:boolean=false;
// options = [
//   {value:null,name:'Select Role'},
//   { value: 1, name: 'role 1' },
//   { value: 2, name: 'role 2' },
//   { value: 3, name: 'role 3' },
// ];

  constructor(public fb:FormBuilder,public auth:AuthService, public router: Router, public dialog:NbDialogService) {}

  ngOnInit() {
    this.registerUser = this.fb.group({
      name:['',Validators.compose([Validators.required,Validators.maxLength(30)])],
      email:['',Validators.compose([Validators.required,Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)])],
      phone:['',Validators.compose([Validators.required,Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/),Validators.maxLength(10)])],
      role:['',Validators.required],
      password:['',Validators.compose([Validators.required,Validators.minLength(6)])],
      confirmPass:['',Validators.required]
    }, {
      validator: MustMatch('password', 'confirmPass')

    });
    console.log(this.f.phone)

  }
  get f(){
    return this.registerUser.controls;
  }
  onSignUp(){
    const sendValue:sendValue = {name:'',email:'',phone:null,password:'',role:''}
    this.submitted = true;
   
    if(this.registerUser.invalid){
      return
    }
    sendValue.name = this.registerUser.value.name;
    sendValue.email = this.registerUser.value.email;
    sendValue.phone = +this.registerUser.value.phone;
    sendValue.role = this.registerUser.value.role;
    sendValue.password = this.registerUser.value.password;
    // this.registerUser.removeControl(name)
    console.log(sendValue)
    this.auth.findUser(sendValue.phone)
      .subscribe(res => {
        this.userExist = res.User ? true : false;
        console.log('User Exist' + this.userExist)
  
      if(!this.userExist){

        this.auth.instituteSignup(sendValue)
          .subscribe(res => {
            console.log(res);     
           this.dialog.open(SuccessComponent, 
            {context:{title:'title'},
          })
          },
          err => console.log(err))
      }
      if(this.userExist){
       const dialogRef = this.dialog.open(DialogComponent, {
          context: {
            title: 'This is a title passed to the dialog component',
          },
        });
    
      }
      })
  }
}
