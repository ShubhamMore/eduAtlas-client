import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
title:string;
  constructor() { }

  ngOnInit() {
  }

}
