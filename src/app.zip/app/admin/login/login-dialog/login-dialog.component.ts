import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-login-dialog',
  templateUrl: './login-dialog.component.html',
  styleUrls: ['./login-dialog.component.scss']
})
export class LoginDialogComponent implements OnInit {
title:string
  constructor() { }

  ngOnInit() {
  }

}
