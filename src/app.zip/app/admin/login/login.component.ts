import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import {AuthService} from '../../services/auth.service';
import {NbDialogService} from "@nebular/theme";
import {LoginDialogComponent} from './login-dialog/login-dialog.component';
@Component({
  selector: 'ngx-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  userExist:boolean;
 login:FormGroup
 submitted:boolean = false;
  constructor(public router: Router, private fb:FormBuilder,private auth:AuthService, private dialog:NbDialogService) { }
 
  ngOnInit() {
    this.login = this.fb.group({
      phone:['',Validators.compose([Validators.required,Validators.pattern(/^([+]?\d{1,2}[.-\s]?)?(\d{3}[.-]?){2}\d{4}/),Validators.maxLength(10)])],
      password:['',Validators.required]
    })
  }
  get f(){
    return this.login.controls;
  }
onSubmit(){
  this.submitted = true;
  if(this.login.invalid){
    return
  }
  console.log(this.login.value);
  this.auth.findUser(this.login.value.phone)
  .subscribe(res => {
    this.userExist = res.User ? true : false;
    console.log('User Exist' + this.userExist)
  
  console.log(this.userExist)
  if(!this.userExist){
    
    this.dialog.open(LoginDialogComponent, {
      context: {
        title: 'This Phone Number Does Not Exist',
      },
    });
    
  }
  if(this.userExist){
    this.login.patchValue({ phone: parseInt(this.login.value.phone, 10) });
    this.auth.instituteLogin(this.login.value).subscribe(
      (data) => {
        console.log('from api:'+' '+data)
        if (!data.token) {
          console.log('No token');
          console.log('Invalid credentials')
          return;
        }
        localStorage.setItem('token',data.token);
        localStorage.setItem('expireIn',JSON.stringify(data.expireIn));
        if(localStorage.getItem('token'))
        {
        this.router.navigate(['/pages/home']);  
        }
        
      },
      err => {console.log(err.status + ' ' + err.statusText);
          this.dialog.open(LoginDialogComponent, {
      context: {
        title: 'Invalid Password',
      },
       });
     })
  }
  });
 
  }

//  console.log(this.login.value);
   
}
